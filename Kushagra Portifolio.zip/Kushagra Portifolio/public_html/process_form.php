<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data and sanitize
    $name = htmlspecialchars($_POST["name"]);
    $email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);
    $message = htmlspecialchars($_POST["message"]);

    // Validate input
    if (empty($name) || empty($email) || empty($message) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Please fill out all fields with valid information.";
        exit;
    }

    // Compose the email
    $to = "kushagra.chaturvedi.bhargava@gmail.com"; // Replace with your email address
    $subject = "New Contact Form Submission";
    $body = "Name: " . $name . "\n";
    $body .= "Email: " . $email . "\n";
    $body .= "Message: " . $message . "\n";

    // Send the email
    if (mail($to, $subject, $body)) {
        // Redirect to a thank-you page
        header("Location: thank_you.html");
        exit;
    } else {
        // Log the error and display a user-friendly message
        error_log("Error sending email in contact form.");
        echo "There was a problem sending your message. Please try again later.";
    }
}
?>